package main;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import java.awt.Font;
import java.awt.Dimension;

public class TelaLogin extends JPanel {
	
	private Janela janela;
	
	public TelaLogin(Janela janela) {
		setPreferredSize(new Dimension(500, 200));
        this.janela = janela;
        
        //Declara e inicializa os componentes da tela.
        JTextField tf_nomeUsuario = new JTextField(15);
        tf_nomeUsuario.setFont(new Font("Tahoma", Font.PLAIN, 20));
        JButton btn_entrar = new JButton("Entrar");
        btn_entrar.setFont(new Font("Tahoma", Font.PLAIN, 20));
        JLabel lb_usuario = new JLabel("Usuário:");
        lb_usuario.setFont(new Font("Tahoma", Font.PLAIN, 20));
        
        //Adiciona os componentes ao painel.
        add(lb_usuario);
        add(tf_nomeUsuario);
        add(btn_entrar);

        //Define as ações dos botões
        btn_entrar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String username = tf_nomeUsuario.getText();
                if (!username.trim().isEmpty()) {
                    janela.mostraTelaPrincipal(username);
                } else {
                    JOptionPane.showMessageDialog(TelaLogin.this, "Usuário não pode ser vazio.");
                }
            }
        });
    }
	
	

}
