package main;

public class Main {
	public static void main(String[] args) {
		Janela frame = new Janela();
		frame.setVisible(true);
	}
}
