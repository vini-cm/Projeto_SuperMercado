package main;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import java.awt.Font;

public class TelaPrincipal extends JPanel {

	private Janela janela;
    private JLabel lb_nomeUsuario;

    public TelaPrincipal(Janela janela) {
        this.janela = janela;

        //Declara e inicializa os componentes da tela.
        lb_nomeUsuario = new JLabel();
        lb_nomeUsuario.setFont(new Font("Tahoma", Font.PLAIN, 20));
        JButton btn_configuracoes = new JButton("Configurações");
        btn_configuracoes.setFont(new Font("Tahoma", Font.PLAIN, 20));
        JButton btn_logout = new JButton("Logout");
        btn_logout.setFont(new Font("Tahoma", Font.PLAIN, 20));
        
        //Adiciona os componentes ao painel.
        add(lb_nomeUsuario);
        add(btn_configuracoes);
        add(btn_logout);

        //Define as ações dos botões
        btn_configuracoes.addActionListener(e -> janela.mostrarTelaConfiguracoes());
        btn_logout.addActionListener(e -> janela.mostrarTela(Janela.LOGIN_PANEL));
    }

    // Método público para ser chamado jframe para atualizar esta tela.
    public void updateWelcomeMessage(String username) {
        lb_nomeUsuario.setText("Olá, " + username + "! Bem-vindo(a) ao sistema.");
    }
}
