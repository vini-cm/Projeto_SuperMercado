package main;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import java.awt.Font;
import java.awt.Dimension;

public class TelaConfiguracoes extends JPanel {

    private Janela janela;
    private JTextField tf_nome;

    public TelaConfiguracoes(Janela janela) {
    	setPreferredSize(new Dimension(500, 300));
        this.janela = janela;

        tf_nome = new JTextField(15);
        tf_nome.setFont(new Font("Tahoma", Font.PLAIN, 20));
        JButton btn_salvarEVoltar = new JButton("Salvar e Voltar");
        btn_salvarEVoltar.setFont(new Font("Tahoma", Font.PLAIN, 20));
        JButton btn_cancelar = new JButton("Cancelar");
        btn_cancelar.setFont(new Font("Tahoma", Font.PLAIN, 20));
        
        JLabel lb_alterarNome = new JLabel("Alterar nome:");
        lb_alterarNome.setFont(new Font("Tahoma", Font.PLAIN, 20));
        add(lb_alterarNome);
        add(tf_nome);
        add(btn_salvarEVoltar);
        add(btn_cancelar);

        btn_salvarEVoltar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String newUsername = tf_nome.getText();
                if (!newUsername.trim().isEmpty()) {
                    // Envia o novo dado para o controlador principal
                    janela.atualizarNomeEMostrarPrincipal(newUsername);
                } else {
                    JOptionPane.showMessageDialog(TelaConfiguracoes.this, "O nome não pode ser vazio.");
                }
            }
        });

        // O botão cancelar simplesmente pede para voltar à tela principal sem salvar
        btn_cancelar.addActionListener(e -> janela.mostrarTela(Janela.MAIN_PANEL));
    }

    // Método para o JFrame configurar esta tela antes de exibi-la
    public void setCurrentUsername(String username) {
        tf_nome.setText(username);
    }
}
