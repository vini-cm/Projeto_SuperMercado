package views;

import javax.swing.JPanel;

public class TelaCadastroDeProdutos extends JPanel {

	private static final long serialVersionUID = 1L;

	/**
	 * Create the panel.
	 */
	public TelaCadastroDeProdutos() {

	}

}
