CREATE DATABASE IF NOT exists CADASTRO;
USE CADASTRO;

CREATE TABLE IF NOT EXISTS usuarios(
	nome VARCHAR(100) NOT NULL,
    cpf VARCHAR(11) NOT NULL UNIQUE,
    funcao boolean
);

INSERT INTO usuarios(nome, cpf)VALUES
	("Vinícius Nunes Bispo", "12014993998",true),
    ("Camila Schmidt", "23565891612");